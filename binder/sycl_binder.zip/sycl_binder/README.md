This software is for SYCL binder and rebinder. SYCL is a royalty-free, cross-platform abstraction layer thatenables code for heterogeneous processors to be written using standard ISO C++ with the host and kernel code for an application contained in the same source file. SYCL standard has been specified by KHRONOS group(https://www.khronos.org/sycl/).

# prerequisits #
- heterogeneous processors, SYCL supported device, include:
	Intel Xeon CPU
	Intel GPU
	Intel FPGA
	NVIDIA GPU (with CUDA 10.2)

- SYCL supported devices but excluded by this software:
	AMD GPU 
	Xilinx FPGA

- OpenCL 2.1 implementattion provided by the vendors 
	ex) OpenCL 2.1 for Intel CPU SDK

- GNU BIN utility and Linker:
	objcopy, ld

- ready for SYCL:
	SYCL compiler : https://github.com/intel/llvm
	how to build SYCL compiler : https://intel.github.io/llvm-docs/GetStartedGuide.html
	

# contents #
compile.sh : bash shell script for compiling and rebinding using given SYCL example code
scan.cpp : SYCL example code for testing, from open-source ComputeCpp SDK(https://github.com/codeplaysoftware/computecpp-sdk)
scan : prebuilt scan program using scan.cpp for Intel CPU and Intel FPGA
README.md : this document

# how to run #
install SYCL device and OpenCL implementation
$clinfo -l 
The above command will show installed device info. Type "$sudo apt-get install -y clinfo" if clinfo is not installed.

Download SYCL compiler
$git clone https://github.com/intel/llvm
Type "$sudo apt-get install git -y" if git is not installed.

Build prerequisits of SYCL compiler and SYCL compiler by following "Get Started Guide".

Change permission compile.sh to execute.
$chmod +x compile.sh

Run the bash script.
$./compile.sh

If you want to run for another SYCL source code, change "SRC" in compile.sh. Also, you can change the target devices.
